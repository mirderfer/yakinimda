class AppConfig {
  // Supabase Dashboard > Project Settings > API
  // Bu iki değer yer tutucudur. service_role key'i buraya koymayın.
  static const supabaseUrl = 'YOUR_SUPABASE_URL';
  static const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
}
