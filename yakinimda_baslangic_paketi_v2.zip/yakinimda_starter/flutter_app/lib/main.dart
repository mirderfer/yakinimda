import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final configured = !AppConfig.supabaseUrl.startsWith('YOUR_') &&
      !AppConfig.supabaseAnonKey.startsWith('YOUR_');

  if (configured) {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
  }

  runApp(YakinimdaApp(backendConfigured: configured));
}

class YakinimdaApp extends StatelessWidget {
  const YakinimdaApp({super.key, required this.backendConfigured});
  final bool backendConfigured;

  static const navy = Color(0xFF10243A);
  static const teal = Color(0xFF16B8A6);
  static const orange = Color(0xFFFF9D45);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Yakınımda',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: teal),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        textTheme: GoogleFonts.interTextTheme(),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: HomeScreen(backendConfigured: backendConfigured),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.backendConfigured});
  final bool backendConfigured;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 0;
  final pages = const [
    _HomeFeed(),
    _NearbyPage(),
    _CreatePage(),
    _DiscoverPage(),
    _ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Icon(Icons.location_on, color: YakinimdaApp.teal),
          const SizedBox(width: 7),
          Text('Yakınımda',
              style: GoogleFonts.inter(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Bildirimler',
            onPressed: () => _notice('Bildirim merkezi sonraki geliştirme aşamasında.'),
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: Column(children: [
        if (!widget.backendConfigured)
          MaterialBanner(
            content: const Text('Demo görünümü: Supabase bağlantısı henüz yapılandırılmadı.'),
            leading: const Icon(Icons.info_outline),
            actions: [TextButton(onPressed: () {}, child: const Text('Tamam'))],
          ),
        Expanded(child: pages[selected]),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (v) => setState(() => selected = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Yakınımda'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'İlan Ver'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Keşfet'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profilim'),
        ],
      ),
    );
  }

  void _notice(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _HomeFeed extends StatelessWidget {
  const _HomeFeed();

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [YakinimdaApp.navy, Color(0xFF1E5265)]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Şehrinde neler oluyor?',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          const Text('Yakınındaki fırsatları, ilanları ve insanları keşfet.',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 15),
          TextField(
            decoration: InputDecoration(
              hintText: 'Ürün, hizmet veya işletme ara',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('Kategoriler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const Wrap(spacing: 9, runSpacing: 9, children: [
        _Category(icon: Icons.directions_car, label: 'Vasıta'),
        _Category(icon: Icons.phone_iphone, label: 'Elektronik'),
        _Category(icon: Icons.home_work_outlined, label: 'Emlak'),
        _Category(icon: Icons.work_outline, label: 'İş ilanları'),
        _Category(icon: Icons.handyman_outlined, label: 'Hizmetler'),
        _Category(icon: Icons.storefront_outlined, label: 'İşletmeler'),
      ]),
      const SizedBox(height: 22),
      const Text('Yakınındaki ilanlar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      const _EmptyCard(
        icon: Icons.store_mall_directory_outlined,
        title: 'İlk ilanlar burada görünecek',
        subtitle: 'Konumunu veya şehir tercihini belirlediğinde çevrendeki ilanları keşfedebileceksin.',
      ),
      const SizedBox(height: 18),
      const Text('Mahallenden paylaşımlar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      const _EmptyCard(
        icon: Icons.forum_outlined,
        title: 'Topluluğunu keşfet',
        subtitle: 'Yerel duyurular, fotoğraflar ve kısa videolar bu alanda yer alacak.',
      ),
    ]);
  }
}

class _NearbyPage extends StatelessWidget {
  const _NearbyPage();
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    icon: Icons.map_outlined,
    title: 'Yakınındaki dünyayı keşfet',
    subtitle: 'Harita, mesafe filtreleri, işletmeler ve yerel hizmetler bağlantı kurulduğunda burada çalışacak.',
  );
}

class _CreatePage extends StatelessWidget {
  const _CreatePage();
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Ne paylaşmak istiyorsun?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    for (final item in [
      (Icons.sell_outlined, 'Ürün / İkinci el ilanı'),
      (Icons.directions_car_outlined, 'Araç / Yedek parça'),
      (Icons.home_work_outlined, 'Emlak ilanı'),
      (Icons.work_outline, 'İş / Eleman ilanı'),
      (Icons.storefront_outlined, 'İşletme / Kampanya'),
      (Icons.campaign_outlined, 'Mahalle duyurusu'),
      (Icons.video_library_outlined, 'Fotoğraf / Video paylaşımı'),
    ])
      Card(child: ListTile(leading: Icon(item.$1), title: Text(item.$2), trailing: const Icon(Icons.chevron_right),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('İlan oluşturma formu sonraki geliştirme aşamasında.'))))),
  ]);
}

class _DiscoverPage extends StatelessWidget {
  const _DiscoverPage();
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    icon: Icons.explore_outlined,
    title: 'Keşfet',
    subtitle: 'Popüler ilanlar, yerel videolar, topluluklar ve öneriler burada olacak.',
  );
}

class _ProfilePage extends StatelessWidget {
  const _ProfilePage();
  @override
  Widget build(BuildContext context) => const _PlaceholderPage(
    icon: Icons.account_circle_outlined,
    title: 'Yakınımda hesabın',
    subtitle: 'E-posta, Google veya telefon/SMS ile kayıt ve giriş ekranları bu bölüme bağlanacak.',
  );
}

class _PlaceholderPage extends StatelessWidget {
  const _PlaceholderPage({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 64, color: YakinimdaApp.teal),
        const SizedBox(height: 16),
        Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
        const SizedBox(height: 8),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.5)),
      ]),
    ),
  );
}

class _Category extends StatelessWidget {
  const _Category({required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Chip(
    avatar: Icon(icon, size: 18, color: YakinimdaApp.navy),
    label: Text(label),
    backgroundColor: Colors.white,
    side: BorderSide.none,
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 9),
  );
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    color: Colors.white,
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 30, color: YakinimdaApp.teal),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.black54, height: 1.4)),
        ])),
      ]),
    ),
  );
}
