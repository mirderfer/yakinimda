# Yakınımda — Ürün gereksinimleri

## Vizyon
Dünya genelindeki kullanıcıların kendi çevrelerinde ürün, hizmet, iş, işletme, fırsat ve topluluk içeriklerini keşfettiği sosyal yerel pazar.

## Kullanıcı rolleri
- Ziyaretçi: herkese açık yayınları sınırlı görüntüler.
- Üye: ilan verir, mesajlaşır, paylaşım yapar, takip eder.
- İşletme: mağaza profili, kampanya, ürün/hizmet kataloğu.
- Moderatör: şikâyet ve inceleme kuyruğunu yönetir.
- Yönetici: tüm platform ayarları ve kullanıcı/ilan yönetimi.
- Süper yönetici: rol ve kritik güvenlik ayarlarını yönetir.

## Üyelik
- E-posta + parola ve e-posta doğrulaması.
- Google OAuth.
- Telefon numarası + SMS OTP.
- Kullanıcı birden fazla giriş yöntemini tek hesaba bağlayabilir; hesap birleştirme güvenli doğrulama gerektirir.
- Ülke kodu seçimi ve uluslararası telefon numarası biçimi.
- Şüpheli girişler için rate limit, CAPTCHA ve oturum yönetimi.

## İlan akışı
1. Üye ilan formunu doldurur.
2. Fotoğraflar zararlı dosya, boyut ve içerik kontrollerinden geçer.
3. Sunucu tarafı moderasyon kuralları ve sınıflandırıcı çalışır.
4. Düşük riskli ilan otomatik yayınlanır.
5. Orta riskli ilan incelemeye gider.
6. Yüksek riskli/yasak içerik reddedilir veya güvenlik ekibine işaretlenir.
7. Her karar gerekçe ve zaman damgasıyla kaydedilir.
8. Yönetici yayınlanmış ilanı düzenleyebilir, kaldırabilir, tekrar incelemeye alabilir.
9. Kullanıcıya karar ve itiraz yolu bildirilir.

## Yönetici araçları
- İlan arama, filtreleme, toplu işlem.
- İlan düzenle, kaldır, reddet, yeniden yayınla.
- Kullanıcı uyar, geçici askıya al, engelle, engeli kaldır.
- Şikâyet kuyruğu ve moderasyon geçmişi.
- Oturum ve güvenlik olayları.
- IP verisine kısıtlı güvenlik erişimi ve admin erişim denetimi.
- Rol tabanlı yetki ve iki aşamalı doğrulama.
- Kritik işlemlerde gerekçe zorunluluğu.

## IP ve güvenlik kayıtları
IP adresi kişisel veri olabilir. Güvenlik olaylarında mümkünse ham IP yerine anahtarlı hash, yaklaşık ülke bilgisi ve olay kaydı tutulur. Ham IP'ye ihtiyaç varsa amaç, saklama süresi, erişim ve silme süreci hukuk/güvenlik incelemesiyle tanımlanır. IP tek başına gerçek kişiyi kesin olarak belirlemez; dinamik IP, VPN, ortak ağ ve mobil operatör NAT'ı dikkate alınmalıdır.

## Global erişim
- Çoklu ülke, dil, para birimi ve saat dilimi.
- Ülke/şehir seçimi; GPS izni zorunlu değil.
- İçerik ve kategori kuralları ülkeye göre yapılandırılabilir.
- Veri aktarımı, verinin barındırıldığı ülke ve yerel mevzuat ayrıca değerlendirilir.

## MVP kapsamı
- Kayıt/giriş.
- Profil.
- İlan oluşturma ve görseller.
- Otomatik moderasyon + yönetici kuyruğu.
- Arama, kategori, şehir/mesafe filtreleri.
- İlan detay ve favori.
- İlan üzerinden mesajlaşma.
- Temel admin paneli.
- Güvenlik olayları ve denetim kaydı.

## Sonraki sürümler
- Harita ve işletme profilleri.
- İş ilanları ve başvurular.
- Yerel duyurular/topluluklar.
- Kısa video ve hikâye.
- Sponsorlu ilanlar, işletme abonelikleri.
- Çoklu dil ve para birimi.
