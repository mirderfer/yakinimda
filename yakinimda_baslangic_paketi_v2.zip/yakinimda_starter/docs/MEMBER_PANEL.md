# Üye paneli — zorunlu modül

Her üye kendi hesabında aşağıdaki alanları görür:

1. **Genel Bakış:** profil tamamlama, aktif ilan sayısı, okunmamış mesaj, favori sayısı, bildirim özeti.
2. **İlanlarım:** taslak, yayında, incelemede, reddedilen ve kaldırılan ilanlar; düzenle, yeniden yayınla, duraklat, sil.
3. **Mesajlarım:** konuşma listesi, okunmamış sayısı, ilan bağlantısı, fotoğraf eki, engelle/şikâyet.
4. **Favorilerim:** favori ilanlar, işletmeler ve kullanıcılar; fiyat değişimi ve ilanın kapanması bildirimleri.
5. **Takip Ettiklerim:** takip edilen üyeler ve işletmeler.
6. **Bildirimler:** mesaj, ilan durumu, favori fiyat değişimi, takip ve yerel duyurular.
7. **Profilim:** fotoğraf, görünen ad, kullanıcı adı, biyografi, şehir ve dil.
8. **Gizlilik ve Güvenlik:** engellenenler, oturumlar, hesap güvenliği, veri indirme ve hesabı silme.
9. **İşletme Araçları:** işletme profili, kampanyalar, ürün/hizmet kataloğu ve temel istatistikler (işletme hesabı olanlarda).

## Mesajlaşma güvenlik kuralları
- Konuşma ve mesajlar yalnızca katılımcılara görünür.
- Yeni konuşma ve mesaj gönderme sunucu tarafında doğrulanır.
- Kullanıcı engeli, mesaj sınırı, spam/flood kontrolü ve raporlama uygulanır.
- Fotoğraf ekleri özel depolama alanında tutulur; kısa ömürlü imzalı bağlantılarla sunulur.
- Yönetici mesaj içeriklerini rutin olarak taramaz; yalnızca geçerli şikâyet, güvenlik olayı ve hukuki süreç kapsamında kısıtlı erişim uygulanır.
- Silme/retention ve yedekleme politikaları ürünün gizlilik metninde açıkça belirtilir.

## Favoriler
Favoriye ekleme/çıkarma anlık ve tekrar çağrılarda mükerrer kayıt oluşturmayacak şekilde tasarlanır. Favori sayısı ve favori listesi yalnızca sahibine özeldir. Favori fiyat/ilan durumu bildirimleri kullanıcının bildirim tercihine bağlıdır.
