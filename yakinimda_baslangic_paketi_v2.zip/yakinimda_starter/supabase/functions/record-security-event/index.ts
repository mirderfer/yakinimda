// Illustrative Supabase Edge Function.
// Configure trusted proxy/IP extraction for your hosting provider before enabling.
// Never trust arbitrary client-supplied IP headers.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return new Response("Unauthorized", { status: 401 });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } },
  );

  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return new Response("Unauthorized", { status: 401 });

  // TODO: obtain client IP only from hosting platform's documented trusted metadata.
  // Do not accept an IP address in the request JSON body.
  // Hash with a server-only secret (HMAC) before storage.
  return Response.json({
    accepted: true,
    user_id: user.id,
    note: "Configure trusted edge IP metadata and keyed hashing before writing security_events."
  });
});
