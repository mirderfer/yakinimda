-- Yakınımda initial schema (Supabase PostgreSQL)
create extension if not exists pgcrypto;

create type public.app_role as enum ('user', 'moderator', 'admin');
create type public.listing_status as enum ('processing', 'published', 'review', 'rejected', 'removed', 'draft');
create type public.moderation_decision as enum ('approved', 'review', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  country_code text,
  city text,
  district text,
  bio text,
  role public.app_role not null default 'user',
  is_suspended boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  title text not null check (char_length(title) between 5 and 120),
  description text not null check (char_length(description) between 10 and 10000),
  price numeric(14,2),
  currency char(3) not null default 'TRY',
  country_code char(2),
  city text,
  district text,
  approximate_latitude double precision,
  approximate_longitude double precision,
  status public.listing_status not null default 'processing',
  moderation_reason text,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.listing_media (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  storage_path text not null,
  media_type text not null check (media_type in ('image','video')),
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table public.moderation_events (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  actor_type text not null check (actor_type in ('automated','admin','moderator')),
  actor_id uuid,
  decision public.moderation_decision not null,
  reason_code text,
  reason_detail text,
  created_at timestamptz not null default now()
);

create table public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Store a keyed hash by default rather than raw IP. Raw IP retention, if truly needed,
-- should be separately assessed, encrypted, access-limited and time-limited.
create table public.security_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  ip_hash text not null,
  event_type text not null,
  user_agent_summary text,
  country_code char(2),
  created_at timestamptz not null default now()
);

create index listings_feed_idx on public.listings(status, created_at desc);
create index listings_location_idx on public.listings(country_code, city, district);
create index listings_user_idx on public.listings(user_id, created_at desc);
create index security_events_user_idx on public.security_events(user_id, created_at desc);

create or replace function public.current_user_role()
returns public.app_role
language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_media enable row level security;
alter table public.moderation_events enable row level security;
alter table public.admin_audit_log enable row level security;
alter table public.security_events enable row level security;

create policy "profiles are readable by authenticated users"
on public.profiles for select to authenticated using (true);

create policy "users update own basic profile"
on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid() and role = public.current_user_role());

create policy "published listings are public"
on public.listings for select to anon, authenticated
using (status = 'published' or user_id = auth.uid() or public.current_user_role() in ('admin','moderator'));

create policy "users create own listings as processing"
on public.listings for insert to authenticated
with check (user_id = auth.uid() and status = 'processing');

create policy "users update own non-published listings"
on public.listings for update to authenticated
using (user_id = auth.uid() and status in ('draft','rejected'))
with check (user_id = auth.uid() and status in ('draft','processing'));

create policy "admins and moderators manage listings"
on public.listings for all to authenticated
using (public.current_user_role() in ('admin','moderator'))
with check (public.current_user_role() in ('admin','moderator'));

create policy "media visible with listing"
on public.listing_media for select to anon, authenticated
using (exists(select 1 from public.listings l where l.id = listing_id and
  (l.status = 'published' or l.user_id = auth.uid() or public.current_user_role() in ('admin','moderator'))));

create policy "owner adds media to own processing listing"
on public.listing_media for insert to authenticated
with check (exists(select 1 from public.listings l where l.id = listing_id and l.user_id = auth.uid() and l.status = 'processing'));

create policy "moderation visible to staff"
on public.moderation_events for select to authenticated
using (public.current_user_role() in ('admin','moderator'));

create policy "audit visible to admins"
on public.admin_audit_log for select to authenticated
using (public.current_user_role() = 'admin');

create policy "security events visible to admins"
on public.security_events for select to authenticated
using (public.current_user_role() = 'admin');

-- Important: role changes, moderation decisions, security-event insertion and IP
-- collection must happen in trusted server-side functions, never from the client.
