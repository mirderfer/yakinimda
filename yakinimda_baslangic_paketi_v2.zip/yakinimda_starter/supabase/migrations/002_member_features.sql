-- Yakınımda: member messaging, favorites, notifications, reports
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);

create table public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  last_read_at timestamptz,
  archived_at timestamptz,
  primary key (conversation_id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text check (body is null or char_length(body) <= 5000),
  attachment_path text,
  message_type text not null default 'text' check (message_type in ('text','image','system')),
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint favorite_target_one_only check (
    (listing_id is not null and profile_id is null) or
    (listing_id is null and profile_id is not null)
  )
);
create unique index favorites_listing_unique on public.favorites(user_id, listing_id) where listing_id is not null;
create unique index favorites_profile_unique on public.favorites(user_id, profile_id) where profile_id is not null;

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  notification_type text not null,
  title text not null,
  body text not null,
  target_type text,
  target_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.user_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid references auth.users(id) on delete set null,
  listing_id uuid references public.listings(id) on delete set null,
  message_id uuid references public.messages(id) on delete set null,
  reason_code text not null,
  details text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create index messages_conversation_time_idx on public.messages(conversation_id, created_at desc);
create index notifications_user_time_idx on public.notifications(user_id, created_at desc);
create index reports_status_time_idx on public.user_reports(status, created_at desc);

alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;
alter table public.notifications enable row level security;
alter table public.user_reports enable row level security;

-- Members can see only conversations they belong to.
create policy "members read own conversations" on public.conversations
for select to authenticated using (
  exists(select 1 from public.conversation_members cm
    where cm.conversation_id = id and cm.user_id = auth.uid())
);

create policy "members read own membership rows" on public.conversation_members
for select to authenticated using (user_id = auth.uid());

create policy "members read messages in own conversations" on public.messages
for select to authenticated using (
  exists(select 1 from public.conversation_members cm
    where cm.conversation_id = conversation_id and cm.user_id = auth.uid())
);

-- Sending messages and creating conversations/membership should be done by a
-- trusted RPC/Edge Function that validates the listing owner, recipient,
-- blocks, rate limits and membership. Do not expose unrestricted inserts.

create policy "users manage own favorites" on public.favorites
for all to authenticated using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "users read own notifications" on public.notifications
for select to authenticated using (user_id = auth.uid());

create policy "users update own notifications" on public.notifications
for update to authenticated using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "users create own reports" on public.user_reports
for insert to authenticated with check (reporter_id = auth.uid());

create policy "reporters read own reports and staff read all" on public.user_reports
for select to authenticated using (
  reporter_id = auth.uid() or public.current_user_role() in ('admin','moderator')
);
